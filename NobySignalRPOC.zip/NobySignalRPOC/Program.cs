using Microsoft.AspNetCore.Builder;
using Microsoft.OpenApi.Models;
using NobySignalRPOC.ChannelBase;
using NobySignalRPOC.SignalRHub;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSignalR().AddSqlServer(builder.Configuration.GetConnectionString("signalR")!);
builder.Services.AddSingleton(typeof(MessageChannel<>));
builder.Services.AddHostedService<ChannelConsumer>();

builder.Services.AddSwaggerGen(options =>
{
    var apiInfo = new OpenApiInfo { Title = "Noby signalR documentation V1", Version = "v1" };
    options.SwaggerDoc("hubs", apiInfo);
    options.AddSignalRSwaggerGen();
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}

app.UseSwagger();
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/hubs/swagger.json", "SignalR_V1");
});
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=SignalRExample}/{id?}");

app.MapHub<NobyHub>("/noby_hub");

app.Run();
