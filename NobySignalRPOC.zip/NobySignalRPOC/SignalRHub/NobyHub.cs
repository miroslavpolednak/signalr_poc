﻿using Microsoft.AspNetCore.SignalR;
using SignalRSwaggerGen.Attributes;
using SignalRSwaggerGen.Enums;

namespace NobySignalRPOC.SignalRHub
{
    [SignalRHub(autoDiscover: AutoDiscover.MethodsAndParams, documentNames: new[] { "hubs" })]
    public class NobyHub : Hub<INobyHub>
    {
        [return: SignalRReturn(typeof(Task), 200, "Success")]
        [SignalRMethod(summary: "Server", description: "Send message to all connected clients, all clients have to be subscribed to ReceiveMessageAll", autoDiscover: AutoDiscover.Params)]
        public async Task SendMessageToAll(string message)
        {
            await Clients.All.ReceiveMessageAll(message);
        }

        [SignalRMethod(summary: "Server", description: "Send message to specific client according to connectionId, user has to be subscribet to ReceiveMessageClient ", autoDiscover: AutoDiscover.Params)]
        [return: SignalRReturn(typeof(Task), 200, "Success")]
        public async Task SendMessageToSpecificClient(string message, string connectionId)
        {
            await Clients.Client(connectionId).ReceiveMessageClient(message);
        }
    }
}
