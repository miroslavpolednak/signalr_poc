﻿using SignalRSwaggerGen.Attributes;
using SignalRSwaggerGen.Enums;

namespace NobySignalRPOC.SignalRHub
{
    [SignalRHub(autoDiscover: AutoDiscover.MethodsAndParams, documentNames: new[] { "hubs" })]
    public interface INobyHub
    {
        [SignalRMethod(summary: "Client", description: "Client have to subscribe to this method, if he want get event from SendMessageToAll (Server hub method)", autoDiscover: AutoDiscover.Params)]
        Task ReceiveMessageAll(string message);

        [SignalRMethod(summary: "Client", description: "Client have to subscribe to this method, if he want get event from SendMessageToSpecificClient (Server hub method)", autoDiscover: AutoDiscover.Params)]
        Task ReceiveMessageClient(string message);
    }
}
