using Microsoft.AspNetCore.Mvc;
using NobySignalRPOC.ChannelBase;
using NobySignalRPOC.Models;
using System.Diagnostics;

namespace NobySignalRPOC.Controllers
{
    //[ApiExplorerSettings(GroupName = "controllers")]
    public class HomeController : Controller
    {
        private readonly MessageChannel<AsyncMessageRequest> _channel;

        public HomeController(
            MessageChannel<AsyncMessageRequest> channel)
        {

            _channel = channel;
        }
        public IActionResult SignalRExample()
        {
            return View();
        }

        public IActionResult Playground()
        {
            return View();
        }

        public async Task<IActionResult> AsyncMessage([FromBody] AsyncMessageRequest request)
        {
            await _channel.ChannelObj.Writer.WriteAsync(request);
            return Accepted();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
