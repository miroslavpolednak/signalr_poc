﻿namespace NobySignalRPOC.Controllers
{
    public class AsyncMessageRequest
    {
        public string ConnectionId { get; set; } = null!;
        public string Message { get; set; } = null!;
    }
}
