﻿using System.Threading.Channels;

namespace NobySignalRPOC.ChannelBase;

public class MessageChannel<T> where T : class
{
    public readonly Channel<T> ChannelObj = Channel.CreateUnbounded<T>();
}
