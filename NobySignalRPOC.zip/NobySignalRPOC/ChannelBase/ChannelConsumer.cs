﻿using Microsoft.AspNetCore.SignalR;
using NobySignalRPOC.Controllers;
using NobySignalRPOC.SignalRHub;

namespace NobySignalRPOC.ChannelBase
{
    public class ChannelConsumer : BackgroundService
    {
        private readonly IHubContext<NobyHub, INobyHub> _hub;
        private readonly MessageChannel<AsyncMessageRequest> _channel;

        public ChannelConsumer(
            IHubContext<NobyHub, INobyHub> hub,
            MessageChannel<AsyncMessageRequest> channel
            )
        {
            _hub = hub;
            _channel = channel;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                var message = await _channel.ChannelObj.Reader.ReadAsync();
                await _hub.Clients.Client(message.ConnectionId).ReceiveMessageClient(message.Message);
            }
        }
    }
}
