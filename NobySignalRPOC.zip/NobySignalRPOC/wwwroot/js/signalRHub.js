﻿class Hub {
    constructor(hubConnectionStr) {
        this.connection = new signalR.HubConnectionBuilder()
            .withAutomaticReconnect()
            .configureLogging(signalR.LogLevel.Information)
            .withUrl(hubConnectionStr)
            .build();
    }

    async connectToHub() {
        try {
            if (this.isConnected() === false) {
                await this.connection.start();
                console.log("SignalR Connected.");
            }
            return this.connection;

        } catch (err) {
            console.error(err);
        }
    }

    getConnection() {
        return this.connection;
    }

    isConnected() {
        return this.connection.state === signalR.HubConnectionState.Connected ? true : false;
    }

    getConnectionId() {
        return this.connection.connection.connectionId;
    }

    closeConnection() {
        try {
            this.connection.stop();
        } catch (err) {
            console.error(err);
        }
    }
}
